Made by scarysss and kot
Made with Love2D
release date 30/03/2023
>:)
WASD - to move
ESC - to close game
